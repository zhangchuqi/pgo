export default {
  RECORD: 'record',
  REPLAY: 'replay',
  PASSTHROUGH: 'passthrough',
  STOPPED: 'stopped'
};
