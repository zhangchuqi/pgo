export default {
  RECORD: 'record',
  WARN: 'warn',
  ERROR: 'error'
};
