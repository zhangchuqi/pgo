module.exports = {
  env: {
    jest: true
  },
  globals: {
    page: true,
    browser: true,
    jestPuppeteer: true
  }
};
