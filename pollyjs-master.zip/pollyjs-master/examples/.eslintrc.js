module.exports = {
  env: {
    node: true,
    browser: true
  }
};
