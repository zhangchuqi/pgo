'use strict';

module.exports = {
  singleQuote: true,
  trailingComma: 'none'
};
