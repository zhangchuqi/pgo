import Adapter from '@pollyjs/adapter';

export default class XHRAdapter extends Adapter<{
  context?: any;
}> {}
