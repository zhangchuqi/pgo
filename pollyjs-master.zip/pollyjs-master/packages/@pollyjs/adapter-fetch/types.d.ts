import Adapter from '@pollyjs/adapter';

export default class FetchAdapter extends Adapter<{
  context?: any;
}> {}
