export const external = [
  'http',
  'https',
  'url',
  'stream',
  'timers',
  'tty',
  'util',
  'os'
];
