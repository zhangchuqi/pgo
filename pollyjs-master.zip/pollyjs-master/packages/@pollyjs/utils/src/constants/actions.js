export default {
  RECORD: 'record',
  REPLAY: 'replay',
  INTERCEPT: 'intercept',
  PASSTHROUGH: 'passthrough'
};
