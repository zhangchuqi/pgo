module.exports = {
  extends: ['plugin:react/recommended'],
  settings: {
    react: {
      version: '16.5.1'
    }
  }
};
