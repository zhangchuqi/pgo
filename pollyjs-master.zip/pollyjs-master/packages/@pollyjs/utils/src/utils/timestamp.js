export default function timestamp() {
  return new Date().toISOString();
}
