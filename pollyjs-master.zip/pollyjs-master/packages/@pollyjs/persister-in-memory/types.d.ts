import Persister from '@pollyjs/persister';

export default class InMemoryPersister extends Persister {}
