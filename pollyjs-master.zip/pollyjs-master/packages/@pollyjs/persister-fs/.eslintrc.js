module.exports = {
  env: {
    browser: false,
    node: true
  }
};
