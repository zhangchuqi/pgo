import createNodeConfig from '../../../scripts/rollup/node.config';

export default createNodeConfig();
