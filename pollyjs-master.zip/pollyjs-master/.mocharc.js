module.exports = {
  spec: './packages/@pollyjs/*/build/node/*.js',
  ui: 'bdd',
  require: 'tests/node-setup.js'
};
